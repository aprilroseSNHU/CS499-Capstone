from data import load_data, save_data, update_animal_list
from animals import Dog, Monkey

# Load initial data
dog_list, monkey_list = load_data()

def display_menu():
    print("\nRescue Animal Management System")
    print("1. Display all dogs")
    print("2. Display all monkeys")
    print("3. Display all animals")
    print("4. Intake a new dog")
    print("5. Intake a new monkey")
    print("6. Search for an animal by name")
    print("7. Update an animal's information")
    print("8. Quit")

def display_dogs():
    print("\nList of Dogs:")
    for dog in dog_list:
        print(dog)

def display_monkeys():
    print("\nList of Monkeys:")
    for monkey in monkey_list:
        print(monkey)

def display_all_animals():
    print("\nAll Animals:")
    display_dogs()
    display_monkeys()

def intake_dog():
    name = input("Enter dog's name: ")
    breed = input("Enter dog's breed: ")
    age = int(input("Enter dog's age: "))
    gender = input("Enter dog's gender: ")
    acquisition_date = input("Enter acquisition date (YYYY-MM-DD): ")
    acquisition_country = input("Enter acquisition country: ")
    training_status = input("Enter training status: ")
    reserved = input("Is the dog reserved? (yes/no): ").strip().lower() == "yes"
    in_service_country = input("Enter in-service country: ")

    if any(d.name.lower() == name.lower() for d in dog_list):
        print("A dog with this name already exists!")
        return

    new_dog = Dog(name, breed, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country)
    dog_list.append(new_dog)
    print("Dog added successfully!")

def intake_monkey():
    name = input("Enter monkey's name: ")
    species = input("Enter monkey's species: ")
    age = int(input("Enter monkey's age: "))
    gender = input("Enter monkey's gender: ")
    acquisition_date = input("Enter acquisition date (YYYY-MM-DD): ")
    acquisition_country = input("Enter acquisition country: ")
    training_status = input("Enter training status: ")
    reserved = input("Is the monkey reserved? (yes/no): ").strip().lower() == "yes"
    in_service_country = input("Enter in-service country: ")

    if any(m.name.lower() == name.lower() for m in monkey_list):
        print("A monkey with this name already exists!")
        return

    new_monkey = Monkey(name, species, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country)
    monkey_list.append(new_monkey)
    print("Monkey added successfully!")

def search_animal():
    name = input("Enter the animal's name: ").strip().lower()
    for animal in dog_list + monkey_list:
        if animal.name.lower() == name:
            print("\nAnimal Found:")
            print(animal)
            return
    print("No animal found with that name.")

def update_animal():
    name = input("Enter the animal's name to update: ").strip().lower()
    animal_type = input("Enter animal type (dog/monkey): ").strip().lower()

    if animal_type == "dog":
        animal_list = dog_list
    elif animal_type == "monkey":
        animal_list = monkey_list
    else:
        print("Invalid animal type.")
        return

    updated_data = {}
    age = input("Enter new age (leave blank to keep current): ")
    if age:
        updated_data["age"] = int(age)
    breed_or_species = input("Enter new breed/species (leave blank to keep current): ")
    if breed_or_species:
        updated_data["breed" if animal_type == "dog" else "species"] = breed_or_species

    if update_animal_list(animal_list, name, updated_data):
        print("Animal updated successfully!")
        save_data(dog_list, monkey_list)  # Save changes to file
    else:
        print("No animal found with that name.")

def main():
    while True:
        display_menu()
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            display_dogs()
        elif choice == "2":
            display_monkeys()
        elif choice == "3":
            display_all_animals()
        elif choice == "4":
            intake_dog()
            save_data(dog_list, monkey_list)  # Save changes to file
        elif choice == "5":
            intake_monkey()
            save_data(dog_list, monkey_list)  # Save changes to file
        elif choice == "6":
            search_animal()
        elif choice == "7":
            update_animal()
        elif choice == "8":
            print("Exiting system. Goodbye!")
            save_data(dog_list, monkey_list)  # Save changes before exiting
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
