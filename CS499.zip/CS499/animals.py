class Animal:
    def __init__(self, name, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country):
        self.name = name
        self.age = age
        self.gender = gender
        self.acquisition_date = acquisition_date
        self.acquisition_country = acquisition_country
        self.training_status = training_status
        self.reserved = reserved
        self.in_service_country = in_service_country

    def __str__(self):
        return (f"Name: {self.name}, Age: {self.age}, Gender: {self.gender}, "
                f"Acquisition Date: {self.acquisition_date}, Acquisition Country: {self.acquisition_country}, "
                f"Training Status: {self.training_status}, Reserved: {self.reserved}, "
                f"In-Service Country: {self.in_service_country}")

class Dog(Animal):
    def __init__(self, name, breed, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country):
        super().__init__(name, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country)
        self.breed = breed

    def __str__(self):
        return super().__str__() + f", Breed: {self.breed}"

class Monkey(Animal):
    def __init__(self, name, species, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country):
        super().__init__(name, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country)
        self.species = species

    def __str__(self):
        return super().__str__() + f", Species: {self.species}"
