import mysql.connector
from animals import Dog, Monkey

# Database connection details
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'AprilRoseSNHU',
    'database': 'rescue_animals'
}


def get_db_connection():
    """Create a connection to the MySQL database."""
    return mysql.connector.connect(**DB_CONFIG)


def load_data():
    """Load the dog and monkey data from the MySQL database."""
    dogs = []
    monkeys = []
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Load dogs
        cursor.execute("SELECT * FROM dogs;")
        dog_rows = cursor.fetchall()
        for dog in dog_rows:
            dogs.append(Dog(
                dog['name'],
                dog['breed'],
                dog['age'],
                dog['gender'],
                dog['acquisition_date'],
                dog['acquisition_country'],
                dog['training_status'],
                dog['reserved'],
                dog['in_service_country']
            ))

        # Load monkeys
        cursor.execute("SELECT * FROM monkeys;")
        monkey_rows = cursor.fetchall()
        for monkey in monkey_rows:
            monkeys.append(Monkey(
                monkey['name'],
                monkey['species'],
                monkey['age'],
                monkey['gender'],
                monkey['acquisition_date'],
                monkey['acquisition_country'],
                monkey['training_status'],
                monkey['reserved'],
                monkey['in_service_country']
            ))

    except mysql.connector.Error as err:
        print(f"Error loading data: {err}")
    finally:
        cursor.close()
        conn.close()

    return dogs, monkeys


def save_data(dogs, monkeys):
    """Save the dog and monkey data to the MySQL database."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Save dogs
        for dog in dogs:
            # Check if the dog already exists
            cursor.execute("SELECT COUNT(*) FROM dogs WHERE name = %s", (dog.name,))
            if cursor.fetchone()[0] == 0:  # Only insert if not found
                cursor.execute("""
                    INSERT INTO dogs (name, breed, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (dog.name, dog.breed, dog.age, dog.gender, dog.acquisition_date, dog.acquisition_country,
                      dog.training_status, dog.reserved, dog.in_service_country))
                print(f"Dog {dog.name} added to the database.")
            else:
                print(f"Dog {dog.name} already exists in the database.")

        # Save monkeys
        for monkey in monkeys:
            # Check if the monkey already exists
            cursor.execute("SELECT COUNT(*) FROM monkeys WHERE name = %s", (monkey.name,))
            if cursor.fetchone()[0] == 0:  # Only insert if not found
                cursor.execute("""
                    INSERT INTO monkeys (name, species, age, gender, acquisition_date, acquisition_country, training_status, reserved, in_service_country)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (monkey.name, monkey.species, monkey.age, monkey.gender, monkey.acquisition_date, monkey.acquisition_country,
                      monkey.training_status, monkey.reserved, monkey.in_service_country))
                print(f"Monkey {monkey.name} added to the database.")
            else:
                print(f"Monkey {monkey.name} already exists in the database.")

        conn.commit()

    except mysql.connector.Error as err:
        print(f"Error saving data: {err}")
    finally:
        cursor.close()
        conn.close()


def update_animal_list(animal_list, name, updated_data):
    """Update the details of an animal in the database."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        for animal in animal_list:
            if animal.name.lower() == name.lower():
                # Update animal details in the database
                if isinstance(animal, Dog):
                    cursor.execute("""
                        UPDATE dogs SET breed=%s, age=%s, gender=%s, acquisition_date=%s, acquisition_country=%s, 
                        training_status=%s, reserved=%s, in_service_country=%s WHERE name=%s
                    """, (updated_data.get('breed', animal.breed), updated_data.get('age', animal.age),
                          updated_data.get('gender', animal.gender),
                          updated_data.get('acquisition_date', animal.acquisition_date),
                          updated_data.get('acquisition_country', animal.acquisition_country),
                          updated_data.get('training_status', animal.training_status),
                          updated_data.get('reserved', animal.reserved),
                          updated_data.get('in_service_country', animal.in_service_country), animal.name))

                elif isinstance(animal, Monkey):
                    cursor.execute("""
                        UPDATE monkeys SET species=%s, age=%s, gender=%s, acquisition_date=%s, acquisition_country=%s, 
                        training_status=%s, reserved=%s, in_service_country=%s WHERE name=%s
                    """, (updated_data.get('species', animal.species), updated_data.get('age', animal.age),
                          updated_data.get('gender', animal.gender),
                          updated_data.get('acquisition_date', animal.acquisition_date),
                          updated_data.get('acquisition_country', animal.acquisition_country),
                          updated_data.get('training_status', animal.training_status),
                          updated_data.get('reserved', animal.reserved),
                          updated_data.get('in_service_country', animal.in_service_country), animal.name))

                conn.commit()
                return True  # Animal found and updated
        return False  # No matching animal found

    except mysql.connector.Error as err:
        print(f"Error updating animal: {err}")
        return False
    finally:
        cursor.close()
        conn.close()
